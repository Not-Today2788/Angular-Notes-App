import { Component } from '@angular/core';

@Component({
  selector: 'app-noteicons',
  templateUrl: './noteicons.component.html',
  styleUrl: './noteicons.component.scss'
})
export class NoteiconsComponent {

}
