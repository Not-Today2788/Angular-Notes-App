export const navbarData = [
    {
        routeLink: 'dashboard',
        icon: 'fal fa-home',
        label: 'Notes',
        label1: 'Reminder',
        label2: 'Edit Labels',
        label3: 'Archive',
        label4: 'Trash'
    }
];