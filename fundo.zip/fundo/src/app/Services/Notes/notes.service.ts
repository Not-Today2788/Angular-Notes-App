import { Injectable } from '@angular/core';
import { HttpService } from '../Http/http.service';
import { HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class NotesService {

  token: any;
  constructor(private httpService: HttpService){ this.token=localStorage.getItem('token')  }

  addNotes(reqData:any){
    let header={
      headers: new HttpHeaders({
        'Content-Type' : 'application/json' ,
        'Authorization' :'Bearer '+this.token
      })
    }
    console.log(this.token)
    return this.httpService.postServiceReset('https://localhost:44376/api/Notes/Add',reqData,true,header)
  }
}
